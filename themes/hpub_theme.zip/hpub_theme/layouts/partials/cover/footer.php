<footer class="content-info" role="contentinfo"></footer>
<script type="text/javascript" src="<?php echo $GLOBALS['js']; ?>"></script>
<?php 

    include(locate_template('layouts/components/fontobserver.php'));
    
?>